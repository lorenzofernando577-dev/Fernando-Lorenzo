package tests;

import org.openqa.selenium.*;
import org.testng.Assert;
import org.testng.annotations.*;
import utils.DriverFactory;

public class CartTest {

WebDriver driver;

@BeforeMethod
@Parameters("browser")
public void setup(String browser){

driver = DriverFactory.getDriver(browser);

driver.get("https://www.saucedemo.com");

driver.findElement(By.id("user-name")).sendKeys("standard_user");
driver.findElement(By.id("password")).sendKeys("secret_sauce");
driver.findElement(By.id("login-button")).click();
}

@Test
public void addProductToCart(){

driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

String cart = driver.findElement(By.className("shopping_cart_badge")).getText();

Assert.assertEquals(cart,"1");
}

@Test
public void failingTest(){

driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

String cart = driver.findElement(By.className("shopping_cart_badge")).getText();

Assert.assertEquals(cart,"5");
}

@AfterMethod
public void teardown(){

driver.quit();
}
}