package tests;

import org.openqa.selenium.*;
import org.testng.Assert;
import org.testng.annotations.*;
import utils.DriverFactory;

public class LoginTest {

WebDriver driver;

@BeforeMethod
@Parameters("browser")
public void setup(String browser){

driver = DriverFactory.getDriver(browser);
driver.get("https://www.saucedemo.com");
}

@Test
public void loginSuccess(){

driver.findElement(By.id("user-name")).sendKeys("standard_user");
driver.findElement(By.id("password")).sendKeys("secret_sauce");
driver.findElement(By.id("login-button")).click();

Assert.assertTrue(driver.getCurrentUrl().contains("inventory"));
}

@Test
public void loginWithoutCredentials(){

driver.findElement(By.id("login-button")).click();

String error = driver.findElement(By.tagName("h3")).getText();

Assert.assertTrue(error.contains("Username is required"));
}

@AfterMethod
public void teardown(){

driver.quit();
}
}