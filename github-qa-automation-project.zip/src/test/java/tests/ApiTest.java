package tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ApiTest {

@Test
public void testDepartments(){

RestAssured.baseURI = "https://www.mercadolibre.com.ar";

Response response = RestAssured
        .given()
        .get("/menu/departments");

Assert.assertEquals(response.statusCode(),200);

String body = response.getBody().asString();

Assert.assertTrue(body.contains("departments"));
}
}